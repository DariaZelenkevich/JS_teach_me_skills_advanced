'use strict'

const proxyurl = "https://cors-anywhere.herokuapp.com/";
const getDataFromAPI = fetch(proxyurl + 'https://api.vk.com/method/friends.get?fields=nickname,sex,bdate&v=5.52&access_token=a47bd03213c864014a569558b856c9eaac961fad20aa940d70e7c6ce4b288310cd9ef24971bd8597b7945');

export default getDataFromAPI;
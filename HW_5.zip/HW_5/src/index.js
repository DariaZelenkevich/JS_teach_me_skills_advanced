'use strict'

import  makeRequest from './services/request';
import getDataFromAPI from './services/fetch';
   
makeRequest();

getDataFromAPI.then(data => data.json()).then(data => {console.log(data)}).catch(error => {console.log(error)});

